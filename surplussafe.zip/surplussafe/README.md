# SurplusSafe — HackSprint MVP

SurplusSafe is a React web-app prototype for surplus-food redistribution. Donor and recipient organisations have separate registration and dashboard flows. Recipient organisations request a quantity without choosing a specific food item. SurplusSafe routes the request to the donor associated with an eligible listing; the donor approves or declines before any quantity is reserved. After approval, the recipient chooses their own rider or a third-party delivery partner.

## Features

- Role-specific registration for **recipient organisations** (NGOs, government schools, food banks, orphanages, community kitchens, etc.) and **donors** (canteens, cloud kitchens, restaurants, caterers, bakeries, etc.)
- Phone OTP demo flow before submitting an application
- Admin review desk for recipient registration/licence numbers and donor FSSAI numbers
- Account record is created only after an admin approves the application
- Separate donor and recipient interfaces after login
- Verified donors can publish available surplus food with quantity, unit, preparation time, storage details, pickup location and deadline
- Recipients request only a quantity; the system routes it to an eligible donor by pickup urgency without exposing a food-choice step
- Donors review each request and approve or decline it; approval reserves available quantity and shows any partial fulfilment
- After approval, recipients assign either their own rider or a third-party provider, with rider name and phone
- Pickup status moves through Pending request → Donor approved → Rider assigned → Picked Up
- Monochrome green visual theme across dashboards, forms and status indicators
- Pickup tracking and impact dashboard
- Browser persistence via `localStorage`
- Responsive styling and food-safety caveats

## Run locally

Requires Node.js LTS and npm.

```bash
npm install
npm run dev
```

Open the local URL printed by Vite, typically `http://localhost:5173`.

## Demo verification flow

This is a **front-end-only prototype**. It does not send real SMS OTPs or verify government/FSSAI records automatically.

- Demo OTP: `123456`
- Demo admin PIN: `246810`

To test the full flow:

1. On the welcome screen, choose **Register organisation**.
2. Select Recipient or Donor and fill the relevant details. Recipient applications require a registration/licence number; donor applications require an FSSAI number.
3. Enter demo OTP `123456` and submit the application. It remains pending; no account is created yet.
4. Return to the welcome screen and open **Admin review portal (demo)**. Enter PIN `246810`.
5. Review the application and choose **Approve & create account**. In a real process, admins must verify documents and licence validity using official sources before approving.
6. Log in with the approved phone number and demo OTP `123456`.
7. Donor accounts can publish food listings. Recipient accounts request only a quantity; the app routes the request to an eligible donor by pickup urgency.
8. Log out, then log in with the donor account. Open **Food requests**, review the requested quantity and approve or decline. Approval reserves the available quantity.
9. Log out and return to the recipient account. Open **My pickups**, choose an organisation rider or third-party provider, enter the rider name and phone, then confirm pickup only after collection has actually happened.

## Build and deploy

```bash
npm run build
npm run preview
```

The production output is `dist/`. The project can be imported into Vercel or Netlify using `npm run build` and `dist` as the output directory.

## Important limitations

- OTP and admin PIN are demonstration-only; there is no real SMS provider, identity verification or secure admin authentication.
- Applications, approved accounts and listings are stored in the current browser's `localStorage`. They do not sync between different devices or browsers and are not suitable for real personal/licence data.
- Admins must verify recipient registration/licence numbers and donor FSSAI numbers externally. This prototype only records the supplied number and an approval decision.
- Recipient requests are routed using a simple deterministic earliest-deadline rule. Donor approval is required before quantity is reserved. Rider assignment is recorded in the browser demo; it does not book a real delivery service.
- SurplusSafe does not certify food safety. Donors must provide accurate preparation/storage details, and organisations must follow applicable food-safety and transport requirements.
- Seeded records are fictional demo data. Estimated impact should not be presented as verified real-world impact.

## Tech stack

- React 18
- Vite 6
- JavaScript / JSX
- Plain CSS
- Lucide React icons
- `localStorage` for local demo persistence
