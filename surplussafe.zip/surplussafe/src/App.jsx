import { useEffect, useMemo, useState } from 'react';
import {
  ArrowDownRight,
  ArrowRight,
  ArrowUpRight,
  Bell,
  Check,
  CheckCircle2,
  ChevronDown,
  Clock3,
  Coffee,
  CookingPot,
  HeartHandshake,
  Leaf,
  LayoutDashboard,
  MapPin,
  Menu,
  PackageCheck,
  Plus,
  Search,
  ShieldCheck,
  SlidersHorizontal,
  Sparkles,
  Sprout,
  Truck,
  Users,
  Wheat,
  X,
  LogOut,
  Phone,
  ShieldCheck as ShieldIcon,
  Building2,
  BadgeCheck,
  ClipboardCheck,
} from 'lucide-react';

const STORAGE_KEY = 'foodloop-hacksprint-v2';
const ACCOUNTS_KEY = 'foodloop-accounts-v2';
const REQUESTS_KEY = 'foodloop-requests-v2';
const APPLICATIONS_KEY = 'foodloop-applications-v2';
const SESSION_KEY = 'foodloop-session-v2';
const DEMO_OTP = '123456';
const DEMO_ADMIN_PIN = '246810';
const RECIPIENT_NAME = 'Community Care NGO';
const CATEGORIES = ['All categories', 'Meals', 'Bakery', 'Produce', 'Packaged food', 'Dairy'];

const CATEGORY_META = {
  Meals: { icon: CookingPot, emoji: '🍲', color: 'sage' },
  Bakery: { icon: Wheat, emoji: '🥐', color: 'peach' },
  Produce: { icon: Sprout, emoji: '🥬', color: 'mint' },
  'Packaged food': { icon: PackageCheck, emoji: '🥡', color: 'lavender' },
  Dairy: { icon: Coffee, emoji: '🥛', color: 'sky' },
};

function plusMinutes(minutes) {
  return new Date(Date.now() + minutes * 60 * 1000).toISOString();
}

function minusMinutes(minutes) {
  return new Date(Date.now() - minutes * 60 * 1000).toISOString();
}

function makeSeedFoods() {
  return [
    {
      id: 'seed-1',
      name: 'Fresh vegetarian meal boxes',
      quantity: 35,
      unit: 'portions',
      category: 'Meals',
      donorName: 'MAIT Campus Canteen',
      location: 'Rohini Sector 14, Delhi',
      preparedAt: minusMinutes(28),
      pickupDeadline: plusMinutes(42),
      storage: 'Kept hot in insulated food containers',
      notes: 'Rice, dal, seasonal sabzi and roti. Please bring clean transport containers.',
      status: 'Available',
      claimedBy: '',
      createdAt: minusMinutes(20),
      isMine: false,
    },
    {
      id: 'seed-2',
      name: 'Assorted bakery snack packs',
      quantity: 24,
      unit: 'packs',
      category: 'Bakery',
      donorName: 'The Daily Crumb',
      location: 'Pitampura, Delhi',
      preparedAt: minusMinutes(54),
      pickupDeadline: plusMinutes(95),
      storage: 'Covered, room-temperature storage',
      notes: 'Mixed buns and bread rolls. Contains wheat; ask donor about other allergens.',
      status: 'Available',
      claimedBy: '',
      createdAt: minusMinutes(45),
      isMine: false,
    },
    {
      id: 'seed-3',
      name: 'Seasonal fruit boxes',
      quantity: 18,
      unit: 'boxes',
      category: 'Produce',
      donorName: 'Green Basket Market',
      location: 'Shalimar Bagh, Delhi',
      preparedAt: minusMinutes(35),
      pickupDeadline: plusMinutes(190),
      storage: 'Stored in a cool, shaded area',
      notes: 'A mix of bananas, apples and oranges. Inspect produce before distribution.',
      status: 'Available',
      claimedBy: '',
      createdAt: minusMinutes(30),
      isMine: false,
    },
    {
      id: 'seed-4',
      name: 'Individually packed lunch bowls',
      quantity: 14,
      unit: 'bowls',
      category: 'Packaged food',
      donorName: 'Northside Office Kitchen',
      location: 'Netaji Subhash Place, Delhi',
      preparedAt: minusMinutes(70),
      pickupDeadline: plusMinutes(70),
      storage: 'Refrigerated after preparation',
      notes: 'Sealed vegetarian lunch bowls. Recipient should maintain the cold chain.',
      status: 'Claimed',
      claimedBy: RECIPIENT_NAME,
      createdAt: minusMinutes(65),
      isMine: false,
    },
    {
      id: 'seed-5',
      name: 'Packed breakfast portions',
      quantity: 20,
      unit: 'portions',
      category: 'Meals',
      donorName: 'Community Hall Kitchen',
      location: 'Rani Bagh, Delhi',
      preparedAt: minusMinutes(210),
      pickupDeadline: minusMinutes(65),
      storage: 'Storage details supplied by donor',
      notes: 'Demo history item for demonstrating an elapsed collection window.',
      status: 'Available',
      claimedBy: '',
      createdAt: minusMinutes(215),
      isMine: false,
    },
    {
      id: 'seed-6',
      name: 'Sealed snack and fruit kits',
      quantity: 20,
      unit: 'kits',
      category: 'Packaged food',
      donorName: 'Helping Hands Community Kitchen',
      location: 'Rohini Sector 9, Delhi',
      preparedAt: minusMinutes(300),
      pickupDeadline: minusMinutes(150),
      storage: 'Sealed packs; follow label directions',
      notes: 'Completed sample record used to preview the impact dashboard.',
      status: 'Picked Up',
      claimedBy: RECIPIENT_NAME,
      createdAt: minusMinutes(315),
      pickedUpAt: minusMinutes(170),
      isPickupRecord: true,
      isMine: false,
    },
  ];
}

function safeLoadFoods() {
  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (!saved) return makeSeedFoods();
    const parsed = JSON.parse(saved);
    return Array.isArray(parsed) ? parsed : makeSeedFoods();
  } catch {
    return makeSeedFoods();
  }
}

function getEffectiveStatus(food, now = Date.now()) {
  if (food.status === 'Picked Up') return 'Picked Up';
  const deadline = new Date(food.pickupDeadline).getTime();
  if (Number.isNaN(deadline) || deadline <= now) return 'Expired';
  return food.status;
}

function getUrgency(food, now = Date.now()) {
  if (getEffectiveStatus(food, now) !== 'Available') return 'Unavailable';
  const minutesLeft = Math.max(0, (new Date(food.pickupDeadline).getTime() - now) / 60000);
  if (minutesLeft <= 60) return 'Urgent';
  if (minutesLeft <= 180) return 'Soon';
  return 'Plenty of time';
}

function formatCountdown(dateString) {
  const diff = new Date(dateString).getTime() - Date.now();
  if (!Number.isFinite(diff) || diff <= 0) return 'Pickup window ended';
  const totalMinutes = Math.ceil(diff / 60000);
  if (totalMinutes < 60) return `${totalMinutes} min left`;
  const hours = Math.floor(totalMinutes / 60);
  const minutes = totalMinutes % 60;
  return minutes ? `${hours}h ${minutes}m left` : `${hours}h left`;
}

function formatTime(dateString) {
  if (!dateString) return '—';
  const date = new Date(dateString);
  if (Number.isNaN(date.getTime())) return '—';
  return new Intl.DateTimeFormat('en-IN', { hour: 'numeric', minute: '2-digit' }).format(date);
}

function formatNumber(value) {
  return new Intl.NumberFormat('en-IN').format(value);
}

function toLocalInputValue(date) {
  const offset = date.getTimezoneOffset() * 60000;
  return new Date(date.getTime() - offset).toISOString().slice(0, 16);
}

function makeInitialForm() {
  return {
    name: '',
    quantity: '20',
    unit: 'portions',
    category: 'Meals',
    location: '',
    preparedAt: toLocalInputValue(new Date()),
    pickupDeadline: toLocalInputValue(new Date(Date.now() + 2 * 60 * 60 * 1000)),
    storage: '',
    notes: '',
  };
}

function StatusPill({ status }) {
  const className = status.toLowerCase().replaceAll(' ', '-');
  return <span className={`status-pill status-${className}`}><span className="status-dot" />{status}</span>;
}

function UrgencyPill({ urgency }) {
  if (urgency === 'Unavailable' || urgency === 'Plenty of time') return null;
  return <span className={`urgency-pill urgency-${urgency.toLowerCase()}`}><Clock3 size={12} />{urgency === 'Urgent' ? 'Pickup soon' : 'Pickup today'}</span>;
}

function FoodArt({ category, compact = false }) {
  const meta = CATEGORY_META[category] || CATEGORY_META.Meals;
  const Icon = meta.icon;
  return (
    <div className={`food-art food-art-${meta.color} ${compact ? 'food-art-compact' : ''}`} aria-hidden="true">
      <span className="food-art-orb food-art-orb-one" />
      <span className="food-art-orb food-art-orb-two" />
      <div className="food-art-icon"><Icon size={compact ? 24 : 32} strokeWidth={1.7} /></div>
      <span className="food-art-emoji">{meta.emoji}</span>
    </div>
  );
}

function SectionHeading({ eyebrow, title, subtitle, action }) {
  return (
    <div className="section-heading">
      <div>
        {eyebrow && <div className="eyebrow">{eyebrow}</div>}
        <h2>{title}</h2>
        {subtitle && <p>{subtitle}</p>}
      </div>
      {action}
    </div>
  );
}

function MetricCard({ icon: Icon, label, value, note, tone = 'green', trend }) {
  return (
    <div className="metric-card">
      <div className={`metric-icon metric-icon-${tone}`}><Icon size={19} strokeWidth={1.8} /></div>
      <div className="metric-label">{label}</div>
      <div className="metric-value-row"><strong>{value}</strong>{trend && <span className="metric-trend"><ArrowUpRight size={13} />{trend}</span>}</div>
      <div className="metric-note">{note}</div>
    </div>
  );
}

function FoodCard({ food, role, onClaim, onPickup, recipientName, compact = false, onDetails }) {
  const status = getEffectiveStatus(food);
  const urgency = getUrgency(food);
  const canClaim = false; // Recipients request quantities; they never select or claim a specific listing.
  const canPickup = role === 'recipient' && status === 'Ready for Pickup' && food.claimedBy === recipientName;
  const isDisabled = status === 'Expired' || status === 'Picked Up';

  return (
    <article className={`food-card ${compact ? 'food-card-compact' : ''}`}>
      <div className="food-card-visual">
        <FoodArt category={food.category} compact={compact} />
        <div className="food-card-overlays"><StatusPill status={status} /><UrgencyPill urgency={urgency} /></div>
        <button className="icon-button food-detail-button" aria-label={`View details for ${food.name}`} onClick={() => onDetails(food)}><ArrowUpRight size={17} /></button>
      </div>
      <div className="food-card-body">
        <div className="food-card-meta"><span>{food.category}</span><span className="meta-dot">•</span><span>{formatTime(food.createdAt)}</span></div>
        <h3>{food.name}</h3>
        <div className="food-quantity"><strong>{formatNumber(Number(food.quantity) || 0)}</strong><span>{food.unit}</span></div>
        <div className="food-detail-line"><MapPin size={14} /><span>{food.location}</span></div>
        <div className="food-detail-line"><Clock3 size={14} /><span>{formatCountdown(food.pickupDeadline)}</span></div>
        {!compact && <div className="food-donor-line"><span className="donor-avatar">{(food.donorName || 'D').charAt(0)}</span><span>{food.donorName || 'Community donor'}</span></div>}
        <div className="food-card-actions">
          {canClaim && <button className="button button-primary button-full" onClick={() => onClaim(food.id)}>Claim food <ArrowRight size={15} /></button>}
          {canPickup && <button className="button button-primary button-full" onClick={() => onPickup(food.id)}><CheckCircle2 size={15} /> Confirm pickup</button>}
          {status === 'Claimed' && !canPickup && <div className="action-note"><Users size={14} /> Reserved after donor approval</div>}
          {status === 'Approved' && <div className="action-note"><Clock3 size={14} /> Awaiting rider selection</div>}
          {status === 'Ready for Pickup' && <div className="action-note action-note-success"><Truck size={14} /> Rider assigned</div>}
          {status === 'Expired' && <div className="action-note action-note-muted"><Clock3 size={14} /> Pickup window ended</div>}
          {status === 'Picked Up' && <div className="action-note action-note-success"><CheckCircle2 size={14} /> Successfully picked up</div>}
        </div>
      </div>
    </article>
  );
}

function EmptyState({ title, description, action }) {
  return (
    <div className="empty-state">
      <div className="empty-state-icon"><Leaf size={24} /></div>
      <h3>{title}</h3>
      <p>{description}</p>
      {action}
    </div>
  );
}

function ListingModal({ onClose, onSubmit, donorName, donorId }) {
  const [form, setForm] = useState(makeInitialForm);
  const [error, setError] = useState('');

  function updateField(event) {
    setForm((current) => ({ ...current, [event.target.name]: event.target.value }));
    setError('');
  }

  function handleSubmit(event) {
    event.preventDefault();
    if (!form.name.trim() || !form.location.trim()) {
      setError('Please add a food name and pickup location.');
      return;
    }
    if (!Number.isFinite(Number(form.quantity)) || Number(form.quantity) <= 0) {
      setError('Quantity must be greater than zero.');
      return;
    }
    const prepared = new Date(form.preparedAt).getTime();
    const deadline = new Date(form.pickupDeadline).getTime();
    if (!Number.isFinite(deadline) || deadline <= Date.now()) {
      setError('Choose a future pickup deadline.');
      return;
    }
    if (!Number.isFinite(prepared) || prepared > deadline) {
      setError('Preparation time must be before the pickup deadline.');
      return;
    }
    onSubmit({
      ...form,
      name: form.name.trim(),
      location: form.location.trim(),
      quantity: Number(form.quantity),
      preparedAt: new Date(form.preparedAt).toISOString(),
      pickupDeadline: new Date(form.pickupDeadline).toISOString(),
      createdAt: new Date().toISOString(),
      id: typeof crypto !== 'undefined' && crypto.randomUUID ? crypto.randomUUID() : `food-${Date.now()}`,
      donorName: donorName || 'Verified food donor',
      status: 'Available',
      claimedBy: '',
      isMine: true,
      donorId,
    });
  }

  return (
    <div className="modal-backdrop" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget) onClose(); }}>
      <section className="modal" role="dialog" aria-modal="true" aria-labelledby="listing-modal-title">
        <div className="modal-header">
          <div><div className="eyebrow">MAKE AN IMPACT</div><h2 id="listing-modal-title">List surplus food</h2><p>Share the details so a recipient can plan a safe, timely pickup.</p></div>
          <button className="icon-button modal-close" aria-label="Close form" onClick={onClose}><X size={19} /></button>
        </div>
        <form onSubmit={handleSubmit} className="listing-form">
          <div className="form-grid">
            <label className="form-field form-field-wide"><span>Food name <b>*</b></span><input name="name" value={form.name} onChange={updateField} placeholder="e.g. Fresh vegetarian meal boxes" maxLength={80} /></label>
            <label className="form-field"><span>Quantity <b>*</b></span><input type="number" min="1" max="10000" name="quantity" value={form.quantity} onChange={updateField} /></label>
            <label className="form-field"><span>Unit</span><select name="unit" value={form.unit} onChange={updateField}><option>portions</option><option>packs</option><option>boxes</option><option>bowls</option><option>kits</option><option>kg</option></select></label>
            <label className="form-field"><span>Category</span><select name="category" value={form.category} onChange={updateField}>{CATEGORIES.slice(1).map((category) => <option key={category}>{category}</option>)}</select></label>
            <label className="form-field"><span>Pickup location <b>*</b></span><input name="location" value={form.location} onChange={updateField} placeholder="Area, city" maxLength={120} /></label>
            <label className="form-field"><span>Prepared at</span><input type="datetime-local" name="preparedAt" value={form.preparedAt} onChange={updateField} /></label>
            <label className="form-field"><span>Pickup deadline <b>*</b></span><input type="datetime-local" name="pickupDeadline" value={form.pickupDeadline} onChange={updateField} /></label>
            <label className="form-field form-field-wide"><span>Storage details <b>*</b></span><input name="storage" value={form.storage} onChange={updateField} placeholder="e.g. Refrigerated, sealed, kept hot" maxLength={160} required /></label>
            <label className="form-field form-field-wide"><span>Additional notes</span><textarea name="notes" value={form.notes} onChange={updateField} placeholder="Ingredients, allergens, container requirements…" rows="3" maxLength={500} /></label>
          </div>
          <div className="food-safety-note"><ShieldCheck size={17} /><p>Share accurate preparation and storage details. SurplusSafe does not certify food safety; recipients must assess suitability before accepting.</p></div>
          {error && <div className="form-error" role="alert">{error}</div>}
          <div className="modal-actions"><button type="button" className="button button-secondary" onClick={onClose}>Cancel</button><button type="submit" className="button button-primary"><Plus size={16} /> Publish listing</button></div>
        </form>
      </section>
    </div>
  );
}

function FoodDetailsModal({ food, onClose, role, onClaim, onPickup, recipientName }) {
  const status = getEffectiveStatus(food);
  const canClaim = false; // Recipient requests are sent to donors for approval.
  const canPickup = role === 'recipient' && status === 'Ready for Pickup' && food.claimedBy === recipientName;
  return (
    <div className="modal-backdrop" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget) onClose(); }}>
      <section className="modal details-modal" role="dialog" aria-modal="true" aria-labelledby="details-title">
        <div className="details-cover"><FoodArt category={food.category} /><button className="icon-button details-close" aria-label="Close details" onClick={onClose}><X size={19} /></button></div>
        <div className="details-content">
          <div className="details-title-row"><div><div className="eyebrow">{food.category}</div><h2 id="details-title">{food.name}</h2></div><StatusPill status={status} /></div>
          <p className="details-donor">Listed by {food.donorName || 'Community donor'}</p>
          <div className="details-info-grid"><div><span>Available quantity</span><strong>{formatNumber(food.quantity)} {food.unit}</strong></div><div><span>Pickup deadline</span><strong>{formatTime(food.pickupDeadline)}</strong></div><div><span>Pickup location</span><strong>{food.location}</strong></div><div><span>Prepared at</span><strong>{formatTime(food.preparedAt)}</strong></div></div>
          <div className="details-note"><strong>Storage information</strong><p>{food.storage || 'No storage details supplied.'}</p></div>
          {food.notes && <div className="details-note"><strong>Donor notes</strong><p>{food.notes}</p></div>}
          <div className="food-safety-note"><ShieldCheck size={17} /><p>Confirm safe storage, transport conditions, and suitability before collection. A listing is not a food-safety certification.</p></div>
          {canClaim && <button className="button button-primary button-full" onClick={() => { onClaim(food.id); onClose(); }}>Claim food <ArrowRight size={15} /></button>}
          {canPickup && <button className="button button-primary button-full" onClick={() => { onPickup(food.id); onClose(); }}><CheckCircle2 size={15} /> Confirm pickup</button>}
        </div>
      </section>
    </div>
  );
}

function RiderChoiceForm({ food, onSave }) {
  const [mode, setMode] = useState(food.riderMode || 'personal');
  const [riderName, setRiderName] = useState(food.riderName || '');
  const [riderPhone, setRiderPhone] = useState(food.riderPhone || '');
  const [provider, setProvider] = useState(food.riderProvider || '');
  const [error, setError] = useState('');

  function submit(event) {
    event.preventDefault();
    if (!riderName.trim() || !/^[6-9]\d{9}$/.test(riderPhone.trim())) {
      setError('Enter the rider name and a valid 10-digit Indian mobile number.');
      return;
    }
    if (mode === 'third-party' && !provider.trim()) {
      setError('Enter the third-party delivery provider name.');
      return;
    }
    onSave(food.id, { mode, riderName: riderName.trim(), riderPhone: riderPhone.trim(), provider: mode === 'third-party' ? provider.trim() : 'Organisation rider' });
  }

  return <form className="rider-choice-card" onSubmit={submit}>
    <div className="rider-choice-heading"><div className="rider-choice-icon"><Truck size={18}/></div><div><strong>Arrange collection</strong><p>Choose who will collect this approved request.</p></div></div>
    <div className="rider-mode-options">
      <label className={mode === 'personal' ? 'rider-mode-option selected' : 'rider-mode-option'}><input type="radio" name={`rider-${food.id}`} value="personal" checked={mode === 'personal'} onChange={() => setMode('personal')}/><span><strong>Our own rider</strong><small>Organisation's personal rider</small></span></label>
      <label className={mode === 'third-party' ? 'rider-mode-option selected' : 'rider-mode-option'}><input type="radio" name={`rider-${food.id}`} value="third-party" checked={mode === 'third-party'} onChange={() => setMode('third-party')}/><span><strong>Third-party rider</strong><small>External delivery partner</small></span></label>
    </div>
    {mode === 'third-party' && <label className="form-field"><span>Delivery provider *</span><input value={provider} onChange={(e) => setProvider(e.target.value)} placeholder="e.g. Local delivery partner" required/></label>}
    <div className="rider-fields"><label className="form-field"><span>Rider name *</span><input value={riderName} onChange={(e) => setRiderName(e.target.value)} placeholder="Full name" required/></label><label className="form-field"><span>Rider phone *</span><input value={riderPhone} onChange={(e) => setRiderPhone(e.target.value.replace(/\D/g, '').slice(0,10))} inputMode="numeric" maxLength={10} placeholder="10-digit mobile" required/></label></div>
    {error && <div className="form-error" role="alert">{error}</div>}
    <button type="submit" className="button button-primary"><Truck size={15}/> Confirm rider & arrange pickup</button>
  </form>;
}

function SurplusSafeDashboard({ account, onLogout }) {
  const [foods, setFoods] = useState(safeLoadFoods);
  const [requests, setRequests] = useState(() => readStoredArray(REQUESTS_KEY));
  const [role] = useState(account.role);
  const [activePage, setActivePage] = useState('overview');
  const [search, setSearch] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('All categories');
  const [showFilters, setShowFilters] = useState(false);
  const [showListingModal, setShowListingModal] = useState(false);
  const [selectedFood, setSelectedFood] = useState(null);
  const [toast, setToast] = useState(null);
  const [mobileNavOpen, setMobileNavOpen] = useState(false);
  const [clock, setClock] = useState(Date.now());
  const [requestedQuantity, setRequestedQuantity] = useState('10');
  const [lastAllocation, setLastAllocation] = useState(null);

  useEffect(() => {
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(foods)); } catch { /* App remains usable if browser storage is unavailable. */ }
  }, [foods]);

  useEffect(() => { storeArray(REQUESTS_KEY, requests); }, [requests]);

  useEffect(() => {
    const tick = window.setInterval(() => setClock(Date.now()), 30000);
    return () => window.clearInterval(tick);
  }, []);

  useEffect(() => {
    if (!toast) return undefined;
    const timeout = window.setTimeout(() => setToast(null), 3600);
    return () => window.clearTimeout(timeout);
  }, [toast]);

  const stats = useMemo(() => {
    const statuses = foods.map((food) => getEffectiveStatus(food, clock));
    const availableFoods = foods.filter((food, index) => statuses[index] === 'Available' && !food.isPickupRecord);
    const pickedUpFoods = foods.filter((food, index) => statuses[index] === 'Picked Up' && food.isPickupRecord);
    const activeFoods = foods.filter((food, index) => ['Available', 'Claimed'].includes(statuses[index]) && !food.isPickupRecord);
    const availablePortions = availableFoods.reduce((sum, food) => sum + (Number(food.quantity) || 0), 0);
    const pickedUpPortions = pickedUpFoods.reduce((sum, food) => sum + (Number(food.quantity) || 0), 0);
    const urgentListings = availableFoods.filter((food) => getUrgency(food, clock) === 'Urgent').length;
    const estimatedKg = pickedUpPortions * 0.5;
    return { availableFoods, pickedUpFoods, activeFoods, availablePortions, pickedUpPortions, urgentListings, estimatedKg, totalListings: foods.filter((food) => !food.isPickupRecord).length };
  }, [foods, clock]);

  const filteredFoods = useMemo(() => {
    const normalizedSearch = search.trim().toLowerCase();
    return [...foods]
      .filter((food) => categoryFilter === 'All categories' || food.category === categoryFilter)
      .filter((food) => {
        if (!normalizedSearch) return true;
        return [food.name, food.location, food.donorName, food.category, food.notes].some((value) => String(value || '').toLowerCase().includes(normalizedSearch));
      })
      .sort((a, b) => {
        const statusA = getEffectiveStatus(a, clock);
        const statusB = getEffectiveStatus(b, clock);
        const groupOrder = (status) => status === 'Available' ? 0 : status === 'Claimed' ? 1 : status === 'Picked Up' ? 2 : 3;
        const groupDiff = groupOrder(statusA) - groupOrder(statusB);
        if (groupDiff !== 0) return groupDiff;
        return new Date(a.pickupDeadline).getTime() - new Date(b.pickupDeadline).getTime();
      });
  }, [foods, search, categoryFilter, clock]);

  const myListings = useMemo(() => foods.filter((food) => food.isMine && (!food.isPickupRecord || food.donorId === account.id)).sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)), [foods]);
  const myPickups = useMemo(() => foods.filter((food) => food.claimedBy === (account.orgName || account.fullName) && food.isPickupRecord).sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)), [foods, account.orgName, account.fullName]);
  const myRequests = useMemo(() => requests.filter((request) => request.recipientId === account.id || request.recipientName === (account.orgName || account.fullName)).sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)), [requests, account.id, account.orgName, account.fullName]);
  const donorRequests = useMemo(() => requests.filter((request) => request.donorId === account.id || !request.donorId).sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)), [requests, account.id]);

  function notify(message, type = 'success') { setToast({ message, type }); }

  function createFood(food) {
    setFoods((current) => [food, ...current]);
    setShowListingModal(false);
    setActivePage('my-listings');
    setSearch('');
    setCategoryFilter('All categories');
    notify('Your food listing is live. Thank you for reducing waste!');
  }

  function claimFood() {
    notify('Recipients request a quantity; the donor must approve before collection is arranged.', 'info');
  }

  function requestFood(event) {
    event.preventDefault();
    const wanted = Math.floor(Number(requestedQuantity));
    if (!Number.isFinite(wanted) || wanted < 1) { notify('Enter a quantity greater than zero.', 'error'); return; }
    const candidates = foods.filter((food) => !food.isPickupRecord && getEffectiveStatus(food) === 'Available' && Number(food.quantity) > 0)
      .sort((a, b) => new Date(a.pickupDeadline).getTime() - new Date(b.pickupDeadline).getTime());
    if (!candidates.length) { notify('No eligible surplus food is available right now.', 'error'); return; }
    const match = candidates[0];
    const requestId = typeof crypto !== 'undefined' && crypto.randomUUID ? crypto.randomUUID() : `request-${Date.now()}`;
    const request = {
      id: requestId,
      sourceFoodId: match.id,
      foodName: match.name,
      category: match.category,
      donorName: match.donorName,
      donorId: match.donorId || '',
      location: match.location,
      pickupDeadline: match.pickupDeadline,
      unit: match.unit,
      requestedQuantity: wanted,
      recipientId: account.id,
      recipientName: account.orgName || account.fullName,
      recipientContact: account.phone || '',
      status: 'Pending',
      createdAt: new Date().toISOString(),
    };
    setRequests((current) => [request, ...current]);
    setLastAllocation(request);
    setActivePage('my-pickups');
    notify('Request sent to the donor. Food will be reserved only after donor approval.', 'success');
  }

  function approveRequest(requestId) {
    const request = requests.find((item) => item.id === requestId);
    if (!request || request.status !== 'Pending') { notify('This request has already been reviewed.', 'error'); return; }
    const source = foods.find((item) => item.id === request.sourceFoodId);
    if (!source || getEffectiveStatus(source) !== 'Available' || Number(source.quantity) <= 0) {
      setRequests((current) => current.map((item) => item.id === requestId ? { ...item, status: 'Rejected', decisionNote: 'The listing is no longer available.', reviewedAt: new Date().toISOString() } : item));
      notify('This listing is no longer available. Request marked unavailable.', 'error');
      return;
    }
    const allocated = Math.min(Number(request.requestedQuantity), Number(source.quantity));
    if (allocated <= 0) { notify('No quantity remains for this request.', 'error'); return; }
    const now = new Date().toISOString();
    const pickupId = typeof crypto !== 'undefined' && crypto.randomUUID ? crypto.randomUUID() : `pickup-${Date.now()}`;
    const remainder = Number(source.quantity) - allocated;
    const pickup = {
      ...source,
      id: pickupId,
      quantity: allocated,
      status: 'Approved',
      claimedBy: request.recipientName,
      recipientId: request.recipientId,
      donorId: source.donorId || account.id,
      claimedAt: now,
      createdAt: now,
      isPickupRecord: true,
      isMine: false,
      sourceFoodId: source.id,
      requestId: request.id,
      requestedQuantity: Number(request.requestedQuantity),
      riderMode: '',
      riderName: '',
      riderPhone: '',
      riderProvider: '',
    };
    setFoods((current) => current.flatMap((food) => {
      if (food.id !== source.id) return [food];
      const updated = { ...food, quantity: remainder, status: remainder > 0 ? 'Available' : 'Claimed', claimedBy: remainder > 0 ? '' : request.recipientName };
      return remainder > 0 ? [updated, pickup] : [{ ...updated }, pickup];
    }));
    setRequests((current) => current.map((item) => item.id === requestId ? { ...item, status: 'Approved', allocatedQuantity: allocated, pickupRecordId: pickupId, reviewedAt: now } : item));
    notify(`Approved ${allocated} ${source.unit}. The recipient can now choose a rider.`, 'success');
  }

  function rejectRequest(requestId) {
    setRequests((current) => current.map((item) => item.id === requestId && item.status === 'Pending' ? { ...item, status: 'Rejected', reviewedAt: new Date().toISOString(), decisionNote: 'Declined by donor.' } : item));
    notify('Request declined. No food quantity was reserved.', 'info');
  }

  function saveRider(pickupId, rider) {
    const pickup = foods.find((food) => food.id === pickupId);
    if (!pickup || pickup.status !== 'Approved' || pickup.claimedBy !== (account.orgName || account.fullName)) {
      notify('Rider details can only be added to your donor-approved request.', 'error');
      return;
    }
    setFoods((current) => current.map((food) => food.id === pickupId ? { ...food, status: 'Ready for Pickup', riderMode: rider.mode, riderName: rider.riderName, riderPhone: rider.riderPhone, riderProvider: rider.provider, riderAssignedAt: new Date().toISOString() } : food));
    notify(`${rider.mode === 'personal' ? 'Your rider' : rider.provider} added. Pickup is ready to coordinate.`, 'success');
  }

  function confirmPickup(id) {
    const food = foods.find((item) => item.id === id);
    if (!food || food.status !== 'Ready for Pickup' || food.claimedBy !== (account.orgName || account.fullName)) {
      notify('Pickup can be confirmed only after the donor approves and a rider is assigned.', 'error');
      return;
    }
    if (new Date(food.pickupDeadline).getTime() <= Date.now()) {
      notify('The pickup window has ended. Contact the donor before marking it as rescued.', 'error');
      return;
    }
    setFoods((current) => current.map((item) => item.id === id ? { ...item, status: 'Picked Up', pickedUpAt: new Date().toISOString() } : item));
    setRequests((current) => current.map((item) => item.id === food.requestId ? { ...item, status: 'Completed', completedAt: new Date().toISOString() } : item));
    notify('Pickup confirmed. The completed quantity now counts toward impact.');
  }

  function resetDemo() {
    const fresh = makeSeedFoods();
    setFoods(fresh);
    setRequests([]);
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(fresh)); localStorage.removeItem(REQUESTS_KEY); } catch { /* Ignore storage failure. */ }
    setActivePage('overview');
    setSearch('');
    setCategoryFilter('All categories');
    notify('Demo data reset to the original sample listings.');
  }

  function selectPage(page) {
    setActivePage(page);
    setMobileNavOpen(false);
    if (page !== 'discover') setSearch('');
  }

  const navigation = [
    { id: 'overview', label: 'Overview', icon: LayoutDashboard },
    ...(role === 'recipient' ? [{ id: 'discover', label: 'Request food', icon: HeartHandshake }] : [{ id: 'requests', label: 'Food requests', icon: ClipboardCheck }]),
    { id: role === 'donor' ? 'my-listings' : 'my-pickups', label: role === 'donor' ? 'My listings' : 'My pickups', icon: role === 'donor' ? PackageCheck : Truck },
    { id: 'impact', label: 'Impact dashboard', icon: Sprout },
  ];

  function pageTitle() {
    if (activePage === 'discover') return { eyebrow: 'RECIPIENT WORKSPACE', title: 'Request food quantity', subtitle: 'Choose a quantity; SurplusSafe routes the request to an eligible donor for approval.' };
    if (activePage === 'my-listings') return { eyebrow: 'DONOR WORKSPACE', title: 'Your food listings', subtitle: 'Manage availability and follow each donation through pickup.' };
    if (activePage === 'requests') return { eyebrow: 'DONOR WORKSPACE', title: 'Recipient food requests', subtitle: 'Review each requested quantity and approve or decline before food is reserved.' };
    if (activePage === 'my-pickups') return { eyebrow: 'RECIPIENT WORKSPACE', title: 'Your pickups', subtitle: 'Keep track of the food you have claimed and collected.' };
    if (activePage === 'impact') return { eyebrow: 'GOOD THINGS ADD UP', title: 'Impact dashboard', subtitle: 'A transparent view of what is listed, claimed and collected.' };
    return { eyebrow: 'YOUR COMMUNITY AT A GLANCE', title: 'Good food deserves a second chance.', subtitle: 'A little coordination can keep good food in circulation and out of the bin.' };
  }

  const currentPage = pageTitle();
  const viewFoods = activePage === 'my-listings' ? myListings : activePage === 'my-pickups' ? myPickups : filteredFoods;
  const displayFoods = activePage === 'discover' ? viewFoods : activePage === 'my-listings' || activePage === 'my-pickups' ? viewFoods : stats.availableFoods;
  const displayHeading = activePage === 'discover' ? 'Request quantity' : activePage === 'my-listings' ? 'All your listings' : activePage === 'my-pickups' ? 'Your claimed food' : 'Needs attention first';

  function FoodGrid({ items, emptyTitle, emptyDescription, compact = false }) {
    if (!items.length) return <EmptyState title={emptyTitle} description={emptyDescription} action={activePage === 'my-listings' && role === 'donor' ? <button className="button button-secondary" onClick={() => setShowListingModal(true)}><Plus size={15} /> Create a listing</button> : undefined} />;
    return <div className={`food-grid ${compact ? 'food-grid-compact' : ''}`}>{items.map((food) => <FoodCard key={food.id} food={food} role={role} recipientName={account.orgName || account.fullName} onClaim={claimFood} onPickup={confirmPickup} compact={compact} onDetails={setSelectedFood} />)}</div>;
  }

  return (
    <div className="app-shell">
      {mobileNavOpen && <button className="mobile-backdrop" aria-label="Close navigation" onClick={() => setMobileNavOpen(false)} />}
      <aside className={`sidebar ${mobileNavOpen ? 'sidebar-open' : ''}`}>
        <div className="brand-lockup">
          <div className="brand-mark"><Leaf size={23} fill="currentColor" /></div>
          <div className="brand-text"><strong>surplussafe<span>.</span></strong><small>RESCUE • REDISTRIBUTE • REPEAT</small></div>
          <button className="icon-button sidebar-close" aria-label="Close navigation" onClick={() => setMobileNavOpen(false)}><X size={18} /></button>
        </div>

        <div className="workspace-switcher"><div className="workspace-avatar"><Sprout size={17} /></div><div className="workspace-copy"><strong>Delhi community</strong><span>HackSprint demo</span></div><ChevronDown size={15} /></div>

        <div className="nav-label">WORKSPACE</div>
        <nav className="main-nav" aria-label="Main navigation">
          {navigation.map(({ id, label, icon: Icon }) => (
            <button key={id} className={`nav-item ${activePage === id ? 'nav-item-active' : ''}`} onClick={() => selectPage(id)}>
              <Icon size={18} strokeWidth={1.8} /><span>{label}</span>
              {id === 'discover' && stats.urgentListings > 0 && <span className="nav-counter">{stats.urgentListings}</span>}
              {id === 'requests' && donorRequests.filter((item) => item.status === 'Pending').length > 0 && <span className="nav-counter nav-counter-green">{donorRequests.filter((item) => item.status === 'Pending').length}</span>}
              {id === 'my-pickups' && myPickups.filter((food) => getEffectiveStatus(food) === 'Claimed').length > 0 && <span className="nav-counter nav-counter-green">{myPickups.filter((food) => getEffectiveStatus(food) === 'Claimed').length}</span>}
            </button>
          ))}
        </nav>

        <div className="sidebar-promo">
          <div className="promo-illustration"><div className="promo-sun" /><Sprout size={27} /><Leaf className="promo-leaf" size={20} /></div>
          <strong>Small actions.<br />Lasting impact.</strong>
          <p>Make surplus food count for your community.</p>
          <button onClick={() => selectPage('impact')}>View impact <ArrowRight size={14} /></button>
        </div>

        <div className="sidebar-bottom">
          <div className="demo-status"><span className="live-dot" /><span>Demo environment</span><span className="demo-status-pill">LOCAL</span></div>
          <button className="reset-demo-button" onClick={resetDemo}><span>Reset sample data</span><ArrowDownRight size={14} /></button>
          <div className="sidebar-footnote">Built for a better food future <HeartHandshake size={14} /></div>
        </div>
      </aside>

      <main className="main-area">
        <header className="topbar">
          <div className="topbar-left">
            <button className="icon-button mobile-menu-button" aria-label="Open navigation" onClick={() => setMobileNavOpen(true)}><Menu size={20} /></button>
            <div className="breadcrumb"><span>SurplusSafe</span><span className="breadcrumb-slash">/</span><strong>{navigation.find((item) => item.id === activePage)?.label || (activePage === 'my-pickups' ? 'My pickups' : 'Overview')}</strong></div>
          </div>
          <div className="topbar-actions">
            <div className="account-role-badge"><span className="live-dot" /> {role === 'donor' ? 'Verified donor' : 'Verified recipient'}</div>
            <button className="icon-button notification-button" aria-label="Demo notifications" onClick={() => notify(`${stats.urgentListings} listing${stats.urgentListings === 1 ? '' : 's'} need timely pickup.`, 'info')}><Bell size={18} /><span /></button>
            <div className="profile-chip"><div className="profile-avatar">{(account.orgName || account.fullName || 'F').charAt(0).toUpperCase()}</div><div className="profile-info"><strong>{account.orgName || account.fullName}</strong><span>{account.fullName} · {role === 'donor' ? 'Food donor' : 'Recipient partner'}</span></div><button className="icon-button logout-button" aria-label="Log out" title="Log out" onClick={onLogout}><LogOut size={16} /></button></div>
          </div>
        </header>

        <div className="page-container">
          <div className="page-heading-row">
            <div className="page-heading"><div className="eyebrow"><span className="eyebrow-line" />{currentPage.eyebrow}</div><h1>{currentPage.title}</h1><p>{currentPage.subtitle}</p></div>
            {role === 'donor' && <button className="button button-primary header-cta" onClick={() => setShowListingModal(true)}><Plus size={17} /> List surplus food</button>}
          </div>

          {activePage === 'overview' && (
            <>
              <section className="welcome-banner">
                <div className="welcome-copy"><div className="welcome-kicker"><Sparkles size={14} /> THE FOOD RESCUE NETWORK</div><h2>Good food. Better connections.</h2><p>{role === 'recipient' ? 'Request a quantity; the donor reviews it before approving collection.' : 'Share surplus food with the community. Every timely pickup means less good food goes to waste.'}</p><button className="button button-light" onClick={() => role === 'donor' ? setShowListingModal(true) : selectPage('discover')}>{role === 'donor' ? 'Create a food listing' : 'Request food quantity'} <ArrowRight size={16} /></button></div>
                <div className="welcome-art" aria-hidden="true"><div className="welcome-art-circle circle-back" /><div className="welcome-art-circle circle-front" /><div className="welcome-bowl"><span>🥗</span></div><div className="welcome-leaf leaf-a"><Leaf size={36} /></div><div className="welcome-leaf leaf-b"><Sprout size={31} /></div><div className="welcome-spark spark-a">✦</div><div className="welcome-spark spark-b">✧</div></div>
                <div className="banner-note"><span className="banner-note-icon"><HeartHandshake size={16} /></span><span>Better together</span></div>
              </section>

              <section className="metrics-grid" aria-label="SurplusSafe overview metrics">
                <MetricCard icon={PackageCheck} tone="green" label="Available portions" value={formatNumber(stats.availablePortions)} note={`${stats.availableFoods.length} listings ready to claim`} trend="Live" />
                <MetricCard icon={Clock3} tone="amber" label="Need pickup soon" value={formatNumber(stats.urgentListings)} note="Eligible listings with ≤ 1 hour left" />
                <MetricCard icon={CheckCircle2} tone="blue" label="Portions picked up" value={formatNumber(stats.pickedUpPortions)} note="Completed records only" />
                <MetricCard icon={Sprout} tone="purple" label="Estimated food diverted" value={`${stats.estimatedKg.toLocaleString('en-IN', { maximumFractionDigits: 1 })} kg`} note="Estimate: 0.5 kg per completed portion" />
              </section>

              <div className="overview-content-grid">
                <section className="content-panel urgent-panel">
                  <div className="panel-heading"><div><div className="eyebrow">PRIORITY PICKUPS</div><h2>{role === 'recipient' ? 'Request food quantity' : 'Your listings in focus'}</h2><p>{role === 'recipient' ? 'SurplusSafe routes your quantity request to the donor for approval.' : 'Your active listings, sorted by pickup deadline.'}</p></div><button className="text-link" onClick={() => selectPage(role === 'recipient' ? 'discover' : 'my-listings')}>{role === 'recipient' ? 'Request quantity' : 'View all'} <ArrowRight size={15} /></button></div>
                  {role === 'recipient' ? (
                    <div className="recipient-auto-match">
                      <div className="auto-match-icon"><Sparkles size={22} /></div>
                      <div><strong>You choose the quantity, not the food item.</strong><p>SurplusSafe routes your request to the donor associated with the most urgent eligible listing. The donor must approve before any quantity is reserved.</p></div>
                      <button className="button button-primary" onClick={() => selectPage('discover')}>Request quantity <ArrowRight size={15} /></button>
                    </div>
                  ) : (
                    <div className="priority-list">
                      {myListings.filter((food) => ['Available', 'Claimed'].includes(getEffectiveStatus(food, clock))).slice(0, 3).map((food) => (
                        <div className="priority-row" key={food.id}><FoodArt category={food.category} compact /><div className="priority-row-copy"><strong>{food.name}</strong><span><MapPin size={12} /> {food.location}</span><small>{formatNumber(food.quantity)} {food.unit}</small></div><div className="priority-row-end"><StatusPill status={getEffectiveStatus(food, clock)} /><span className="priority-time"><Clock3 size={12} /> {formatCountdown(food.pickupDeadline)}</span><button className="small-arrow-button" aria-label={`View ${food.name}`} onClick={() => setSelectedFood(food)}><ArrowRight size={15} /></button></div></div>
                      ))}
                      {!myListings.length && <div className="inline-empty">You have not created any listings yet. Share surplus food to get started.</div>}
                    </div>
                  )}
                </section>

                <section className="content-panel impact-preview-panel">
                  <div className="panel-heading"><div><div className="eyebrow">COMMUNITY IMPACT</div><h2>Every portion matters</h2><p>See what has been collected so far in this demo.</p></div></div>
                  <div className="impact-big-number"><span>{formatNumber(stats.pickedUpPortions)}</span><span className="impact-sprout"><Sprout size={22} /></span></div>
                  <div className="impact-big-label">portions recorded as picked up</div>
                  <div className="impact-progress-label"><span>Pickup completion</span><strong>{stats.totalListings ? Math.round(stats.pickedUpFoods.length / stats.totalListings * 100) : 0}%</strong></div>
                  <div className="progress-track"><div className="progress-fill" style={{ width: `${stats.totalListings ? Math.max(0, Math.min(100, stats.pickedUpFoods.length / stats.totalListings * 100)) : 0}%` }} /></div>
                  <div className="impact-mini-stats"><div><span>Listings created</span><strong>{stats.totalListings}</strong></div><div><span>Completed pickups</span><strong>{stats.pickedUpFoods.length}</strong></div></div>
                  <button className="button button-secondary button-full" onClick={() => selectPage('impact')}>Explore impact dashboard <ArrowRight size={15} /></button>
                  <p className="impact-footnote">Demo data shown. Weight is estimated using 0.5 kg per completed portion, not directly measured.</p>
                </section>
              </div>

              <section className="how-it-works-strip"><div className="how-strip-title"><div className="how-strip-icon"><Leaf size={18} /></div><div><strong>Food rescue, made practical</strong><span>One clear workflow from surplus to pickup.</span></div></div><div className="how-step"><span>01</span><div><strong>List</strong><small>Share what's available</small></div></div><ArrowRight className="how-arrow" size={17} /><div className="how-step"><span>02</span><div><strong>Match</strong><small>Find a recipient</small></div></div><ArrowRight className="how-arrow" size={17} /><div className="how-step"><span>03</span><div><strong>Collect</strong><small>Confirm the pickup</small></div></div></section>
            </>
          )}

          {activePage === 'discover' && role === 'recipient' && (
            <>
              <section className="request-hero-panel">
                <div className="request-hero-icon"><HeartHandshake size={25} /></div>
                <div className="request-hero-copy"><div className="eyebrow">RECIPIENT REQUEST</div><h2>How much food does your organisation need?</h2><p>Choose only the quantity you need. SurplusSafe routes the request to the donor of an eligible listing; no food is reserved until the donor approves it.</p></div>
              </section>
              <section className="content-panel request-form-panel">
                <form onSubmit={requestFood} className="quantity-request-form">
                  <label className="form-field"><span>Quantity required <b>*</b></span><input type="number" min="1" max="10000" step="1" value={requestedQuantity} onChange={(event) => setRequestedQuantity(event.target.value)} required /><small>Enter the number of units needed. The donor will review availability before approving.</small></label>
                  <div className="matching-rules"><div><Clock3 size={17}/><span>Urgency decides which donor receives the request</span></div><div><ShieldCheck size={17}/><span>Expired listings are excluded</span></div><div><PackageCheck size={17}/><span>Donor approval required before reservation</span></div></div>
                  <button type="submit" className="button button-primary"><HeartHandshake size={16}/> Send request to donor <ArrowRight size={15}/></button>
                </form>
                {lastAllocation && <div className="allocation-result"><div className="allocation-result-icon"><CheckCircle2 size={22}/></div><div><strong>Request sent for donor approval</strong><p>Your request for {lastAllocation.requestedQuantity} {lastAllocation.unit} has been sent to {lastAllocation.donorName}. No food quantity has been reserved yet.</p><small>Check My pickups for the decision and rider arrangement after approval.</small></div></div>}
              </section>
              <div className="notice-strip"><ShieldCheck size={18}/><div><strong>Safe collection matters</strong><p>Review preparation and storage details after allocation, and coordinate with the donor before travel. SurplusSafe does not certify food safety.</p></div></div>
            </>
          )}

          {activePage === 'requests' && role === 'donor' && (
            <>
              <div className="listing-summary-strip"><div className="summary-strip-icon"><ClipboardCheck size={19}/></div><div><strong>Approval before reservation</strong><p>Review the requested quantity and available stock. Approving reserves the quantity and notifies the recipient to arrange a rider.</p></div></div>
              <div className="section-inline-heading"><div><h2>Requests for your listings</h2><p>Only donor-approved requests move to rider selection.</p></div><span className="subtle-count">{donorRequests.filter((item) => item.status === 'Pending').length} pending</span></div>
              {donorRequests.length ? <div className="request-review-list">{donorRequests.map((request) => {
                const source = foods.find((food) => food.id === request.sourceFoodId);
                const available = source ? Number(source.quantity) : 0;
                return <article className="request-review-card" key={request.id}>
                  <div className="request-review-top"><div className="request-review-icon"><HeartHandshake size={19}/></div><div className="request-review-title"><strong>{request.recipientName}</strong><span>Requested {request.requestedQuantity} {request.unit} · {new Date(request.createdAt).toLocaleString('en-IN', { dateStyle: 'medium', timeStyle: 'short' })}</span></div><span className={`request-status request-status-${request.status.toLowerCase()}`}>{request.status}</span></div>
                  <div className="request-review-details"><div><span>Matched listing</span><strong>{request.foodName}</strong></div><div><span>Available now</span><strong>{available} {request.unit}</strong></div><div><span>Pickup deadline</span><strong>{formatTime(request.pickupDeadline)}</strong></div><div><span>Recipient contact</span><strong>{request.recipientContact || 'Not provided in demo'}</strong></div></div>
                  {request.status === 'Pending' ? <div className="request-review-actions"><button className="button button-secondary" onClick={() => rejectRequest(request.id)}>Decline request</button><button className="button button-primary" onClick={() => approveRequest(request.id)} disabled={!source || available <= 0 || getEffectiveStatus(source) !== 'Available'}><CheckCircle2 size={15}/> Approve & reserve quantity</button></div> : <div className="request-review-note"><ShieldCheck size={15}/><span>{request.status === 'Approved' ? `Approved: ${request.allocatedQuantity} ${request.unit} reserved. Recipient can now select a rider.` : request.status === 'Completed' ? 'Pickup completed.' : request.decisionNote || 'No quantity was reserved.'}</span></div>}
                </article>;
              })}</div> : <EmptyState title="No requests yet" description="When a recipient requests a quantity from one of your listings, it will appear here for your approval."/>}
            </>
          )}

          {activePage === 'my-listings' && (
            <>
              <div className="listing-summary-strip"><div className="summary-strip-icon"><CookingPot size={19} /></div><div><strong>Your community listings</strong><p>Your verified organisation's listings are saved in this browser demo. Keep availability and pickup details current.</p></div><button className="button button-primary" onClick={() => setShowListingModal(true)}><Plus size={16} /> Add listing</button></div>
              <div className="section-inline-heading"><div><h2>All your listings</h2><p>Track what is available, claimed, collected or past its pickup window.</p></div><span className="subtle-count">{myListings.length} total</span></div>
              <FoodGrid items={myListings} emptyTitle="Your first listing starts here" emptyDescription="Have surplus food? Add the details and give your community a chance to collect it." />
            </>
          )}

          {activePage === 'my-pickups' && (
            <>
              <div className="listing-summary-strip pickup-summary-strip"><div className="summary-strip-icon"><Truck size={19} /></div><div><strong>Donor approval → rider choice → pickup</strong><p>Your request is not reserved until the donor approves. After approval, choose your own rider or a third-party delivery partner.</p></div><button className="button button-secondary" onClick={() => selectPage('discover')}>Request food <ArrowRight size={15} /></button></div>
              <div className="section-inline-heading"><div><h2>Your requests</h2><p>Track donor decisions and see what happens next.</p></div><span className="subtle-count">{myRequests.length} request{myRequests.length === 1 ? '' : 's'}</span></div>
              {myRequests.length ? <div className="recipient-request-list">{myRequests.map((request) => <article className="recipient-request-card" key={request.id}><div className="request-review-top"><div className="request-review-icon"><PackageCheck size={19}/></div><div className="request-review-title"><strong>{request.requestedQuantity} {request.unit} · {request.donorName}</strong><span>Request sent {new Date(request.createdAt).toLocaleString('en-IN', { dateStyle: 'medium', timeStyle: 'short' })}</span></div><span className={`request-status request-status-${request.status.toLowerCase()}`}>{request.status}</span></div><p className="recipient-request-message">{request.status === 'Pending' ? 'Waiting for the donor to approve availability. No food has been reserved yet.' : request.status === 'Approved' ? `Donor approved ${request.allocatedQuantity} ${request.unit}. Choose a rider in the pickup card below.` : request.status === 'Completed' ? 'Pickup completed. Thank you for helping reduce food waste.' : request.decisionNote || 'The donor declined this request; no food was reserved.'}</p></article>)}</div> : <EmptyState title="No requests yet" description="Request a quantity to start. You will see donor approval status here."/>}
              <div className="section-inline-heading"><div><h2>Approved pickups</h2><p>After donor approval, arrange a rider and confirm collection.</p></div><span className="subtle-count">{myPickups.length} pickup record{myPickups.length === 1 ? '' : 's'}</span></div>
              {myPickups.length ? <div className="recipient-pickup-list">{myPickups.map((food) => <article className="recipient-pickup-card" key={food.id}><div className="recipient-pickup-summary"><FoodArt category={food.category} compact/><div className="recipient-pickup-copy"><strong>{food.name}</strong><span>{food.quantity} {food.unit} · {food.donorName}</span><small><MapPin size={12}/> {food.location} · <Clock3 size={12}/> {formatCountdown(food.pickupDeadline)}</small><StatusPill status={getEffectiveStatus(food, clock)}/></div></div>{food.status === 'Approved' && getEffectiveStatus(food, clock) === 'Approved' && <RiderChoiceForm food={food} onSave={saveRider}/>}{food.status === 'Ready for Pickup' && getEffectiveStatus(food, clock) === 'Ready for Pickup' && <div className="rider-confirm-panel"><div><strong><Truck size={15}/> Rider assigned: {food.riderName}</strong><p>{food.riderMode === 'third-party' ? `${food.riderProvider} · ` : 'Organisation rider · '}{food.riderPhone}. Contact the donor and rider before travelling.</p></div><button className="button button-primary" onClick={() => confirmPickup(food.id)}><CheckCircle2 size={15}/> Confirm pickup</button></div>}{food.status === 'Picked Up' && <div className="request-review-note"><CheckCircle2 size={15}/><span>Pickup completed on {new Date(food.pickedUpAt).toLocaleString('en-IN', { dateStyle: 'medium', timeStyle: 'short' })}.</span></div>}</article>)}</div> : <EmptyState title="No approved pickups yet" description="Once a donor approves one of your requests, rider arrangements will appear here."/>}
            </>
          )}

          {activePage === 'impact' && (
            <>
              <div className="impact-hero"><div className="impact-hero-copy"><div className="welcome-kicker"><Sprout size={14} /> MEASURE WHAT MATTERS</div><h2>Small actions add up.</h2><p>SurplusSafe separates food that is offered from food that has actually been collected. That keeps the impact story grounded in completed actions.</p></div><div className="impact-hero-icon"><Leaf size={60} /><span>✦</span></div></div>
              <div className="metrics-grid impact-metrics-grid"><MetricCard icon={PackageCheck} label="Food listings" value={formatNumber(stats.totalListings)} note="All records in this demo" tone="green" /><MetricCard icon={Users} label="Portions available" value={formatNumber(stats.availablePortions)} note="Not yet claimed" tone="amber" /><MetricCard icon={CheckCircle2} label="Portions collected" value={formatNumber(stats.pickedUpPortions)} note="Picked Up status only" tone="blue" /><MetricCard icon={Sprout} label="Estimated food diverted" value={`${stats.estimatedKg.toLocaleString('en-IN', { maximumFractionDigits: 1 })} kg`} note="Modelled estimate, not measured weight" tone="purple" /></div>
              <div className="impact-content-grid"><section className="content-panel"><div className="panel-heading"><div><div className="eyebrow">LISTING STATUS</div><h2>From listing to pickup</h2><p>A claimed listing is not counted as a completed rescue.</p></div></div><div className="status-breakdown">{[{label:'Available',count:foods.filter((food) => !food.isPickupRecord && getEffectiveStatus(food, clock) === 'Available'),color:'breakdown-green'},{label:'Claimed',count:foods.filter((food) => !food.isPickupRecord && getEffectiveStatus(food, clock) === 'Claimed'),color:'breakdown-amber'},{label:'Picked up',count:stats.pickedUpFoods,color:'breakdown-blue'},{label:'Expired',count:foods.filter((food) => !food.isPickupRecord && getEffectiveStatus(food, clock) === 'Expired'),color:'breakdown-muted'}].map((item) => <div className="breakdown-row" key={item.label}><div className="breakdown-label"><span className={`breakdown-dot ${item.color}`} />{item.label}</div><div className="breakdown-bar"><span className={item.color} style={{ width: `${foods.length ? Math.max(item.count.length ? 3 : 0, item.count.length / foods.length * 100) : 0}%` }} /></div><strong>{item.count.length}</strong></div>)}</div></section><section className="content-panel impact-assumptions"><div className="panel-heading"><div><div className="eyebrow">METHODOLOGY</div><h2>How estimates work</h2><p>Transparent numbers build trust.</p></div></div><div className="assumption-card"><div className="assumption-icon"><Check size={17} /></div><div><strong>Completed pickup records only</strong><p>Food is counted as collected only when its status is Picked Up.</p></div></div><div className="assumption-card"><div className="assumption-icon assumption-icon-light"><Sprout size={17} /></div><div><strong>0.5 kg per completed portion</strong><p>Illustrative conversion assumption for the demo. Replace with measured weights in a real deployment.</p></div></div><div className="assumption-card"><div className="assumption-icon assumption-icon-light"><ShieldCheck size={17} /></div><div><strong>No verified real-world totals</strong><p>Sample entries are fictional demo records, not proof of food actually rescued.</p></div></div></section></div>
              <div className="impact-cta"><div><strong>{role === 'recipient' ? 'Ready to request a pickup?' : 'Ready to list surplus food?'}</strong><span>{role === 'recipient' ? 'Choose the quantity and let SurplusSafe match an eligible listing.' : 'Publish your currently available surplus for verified recipients.'}</span></div><button className="button button-primary" onClick={() => role === 'recipient' ? selectPage('discover') : setShowListingModal(true)}>{role === 'recipient' ? 'Request quantity' : 'List surplus food'} <ArrowRight size={15} /></button></div>
            </>
          )}

          <footer className="page-footer"><span>© 2026 SurplusSafe • HackSprint prototype</span><span><span className="footer-leaf"><Leaf size={13} /></span> Less waste, more good.</span></footer>
        </div>
      </main>

      {showListingModal && <ListingModal onClose={() => setShowListingModal(false)} onSubmit={createFood} donorName={account.orgName || account.fullName} donorId={account.id} />}
      {selectedFood && <FoodDetailsModal food={foods.find((item) => item.id === selectedFood.id) || selectedFood} onClose={() => setSelectedFood(null)} role={role} recipientName={account.orgName || account.fullName} onClaim={claimFood} onPickup={confirmPickup} />}
      {toast && <div className={`toast toast-${toast.type}`} role="status"><span className="toast-icon">{toast.type === 'error' ? <X size={17} /> : toast.type === 'info' ? <Bell size={17} /> : <CheckCircle2 size={17} />}</span><span>{toast.message}</span><button aria-label="Dismiss notification" onClick={() => setToast(null)}><X size={15} /></button></div>}
    </div>
  );
}


const RECIPIENT_TYPES = ['NGO', 'Government school', 'Food bank', 'Orphanage', 'Community kitchen', 'Other'];
const DONOR_TYPES = ['Canteen', 'Cloud kitchen', 'Restaurant', 'Caterer', 'Bakery', 'Event organiser', 'Other'];

function readStoredArray(key) {
  try { const value = JSON.parse(localStorage.getItem(key) || '[]'); return Array.isArray(value) ? value : []; } catch { return []; }
}
function storeArray(key, value) { try { localStorage.setItem(key, JSON.stringify(value)); } catch { /* local demo storage only */ } }

function AuthPortal({ onAuthenticated }) {
  const [screen, setScreen] = useState('welcome');
  const [role, setRole] = useState('recipient');
  const [form, setForm] = useState({ fullName: '', phone: '', email: '', orgName: '', orgType: RECIPIENT_TYPES[0], registrationNumber: '', fssaiNumber: '', address: '' });
  const [phone, setPhone] = useState('');
  const [otp, setOtp] = useState('');
  const [adminPin, setAdminPin] = useState('');
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');
  const [applications, setApplications] = useState(() => readStoredArray(APPLICATIONS_KEY));
  const [otpPurpose, setOtpPurpose] = useState('');

  function updateForm(event) { setForm((current) => ({ ...current, [event.target.name]: event.target.value })); setError(''); }
  function go(next) { setScreen(next); setError(''); setNotice(''); setOtp(''); }
  function validPhone(value) { return /^[6-9]\d{9}$/.test(value.replace(/\s+/g, '')); }

  function startRegistration(event) {
    event.preventDefault();
    if (!form.fullName.trim() || !validPhone(form.phone) || !form.orgName.trim() || !form.address.trim()) { setError('Please complete all required fields and enter a valid 10-digit Indian mobile number.'); return; }
    if (role === 'recipient' && !form.registrationNumber.trim()) { setError('Enter the organisation registration / licence number for admin verification.'); return; }
    if (role === 'donor' && !form.fssaiNumber.trim()) { setError('Enter the FSSAI registration/licence number for admin verification.'); return; }
    const existing = readStoredArray(APPLICATIONS_KEY).find((item) => item.phone === form.phone && item.status === 'Pending');
    if (existing) { setError('A verification application for this phone number is already pending. Use the admin demo portal to review it.'); return; }
    setOtpPurpose('register'); setPhone(form.phone); go('register-otp');
  }

  function submitRegistrationOtp(event) {
    event.preventDefault();
    if (otp !== DEMO_OTP) { setError(`Incorrect demo OTP. Enter ${DEMO_OTP}.`); return; }
    const app = { ...form, id: `app-${Date.now()}`, role, status: 'Pending', submittedAt: new Date().toISOString(), verifiedPhone: true };
    const updated = [...readStoredArray(APPLICATIONS_KEY), app];
    storeArray(APPLICATIONS_KEY, updated); setApplications(updated);
    setNotice('Phone demo-verified. Your organisation is awaiting admin document verification. No account is created until approval.');
    setScreen('pending'); setError('');
  }

  function startLogin(event) {
    event.preventDefault();
    if (!validPhone(phone)) { setError('Enter a valid 10-digit Indian mobile number.'); return; }
    setOtpPurpose('login'); setOtp(''); setError(''); setNotice('Demo OTP is ready.'); setScreen('login-otp');
  }

  function finishLogin(event) {
    event.preventDefault();
    if (otp !== DEMO_OTP) { setError(`Incorrect demo OTP. Enter ${DEMO_OTP}.`); return; }
    const accounts = readStoredArray(ACCOUNTS_KEY);
    const account = accounts.find((item) => item.phone === phone && item.status === 'Approved');
    if (account) { onAuthenticated(account); return; }
    const pending = readStoredArray(APPLICATIONS_KEY).find((item) => item.phone === phone && item.status === 'Pending');
    if (pending) { setError('Your organisation is still awaiting admin approval.'); return; }
    setError('No approved account found for this phone number. Register your organisation first.');
  }

  function enterAdmin(event) {
    event.preventDefault();
    if (adminPin !== DEMO_ADMIN_PIN) { setError(`Incorrect demo admin PIN. Use ${DEMO_ADMIN_PIN}.`); return; }
    go('admin');
  }

  function reviewApplication(id, decision) {
    const current = readStoredArray(APPLICATIONS_KEY);
    const application = current.find((item) => item.id === id);
    if (!application) return;
    const status = decision === 'approve' ? 'Approved' : 'Rejected';
    const updatedApps = current.map((item) => item.id === id ? { ...item, status, reviewedAt: new Date().toISOString() } : item);
    storeArray(APPLICATIONS_KEY, updatedApps); setApplications(updatedApps);
    if (decision === 'approve') {
      const accounts = readStoredArray(ACCOUNTS_KEY);
      const account = { id: application.id, role: application.role, fullName: application.fullName, phone: application.phone, email: application.email, orgName: application.orgName, orgType: application.orgType, address: application.address, registrationNumber: application.registrationNumber || '', fssaiNumber: application.fssaiNumber || '', status: 'Approved', approvedAt: new Date().toISOString() };
      storeArray(ACCOUNTS_KEY, [...accounts.filter((item) => item.phone !== account.phone), account]);
    }
  }

  const pendingApps = applications.filter((item) => item.status === 'Pending');
  return (
    <div className="auth-shell">
      <div className="auth-top-brand"><div className="brand-mark"><Leaf size={23} fill="currentColor" /></div><div className="brand-text"><strong>surplussafe<span>.</span></strong><small>RESCUE • REDISTRIBUTE • REPEAT</small></div><span className="auth-demo-label">HACKSPRINT DEMO</span></div>
      <div className="auth-main">
        {screen === 'welcome' && <section className="auth-card auth-welcome"><div className="auth-eyebrow"><Sprout size={15}/> FOOD RESCUE NETWORK</div><h1>Good food deserves<br/>a second chance.</h1><p className="auth-subtitle">A verified network connecting surplus-food donors with organisations that can distribute it responsibly.</p><div className="auth-feature-row"><div><PackageCheck size={20}/><strong>Verified partners</strong><span>Admin-reviewed organisations</span></div><div><Clock3 size={20}/><strong>Urgency matching</strong><span>Earlier pickup deadlines first</span></div><div><HeartHandshake size={20}/><strong>Tracked pickups</strong><span>From allocation to collection</span></div></div><div className="auth-actions"><button className="button button-primary" onClick={() => go('login')}><Phone size={16}/> Login with OTP</button><button className="button button-secondary" onClick={() => go('register-role')}>Register organisation <ArrowRight size={16}/></button></div><button className="auth-admin-link" onClick={() => go('admin-login')}><ShieldIcon size={15}/> Admin review portal (demo)</button></section>}

        {screen === 'login' && <section className="auth-card auth-form-card"><button className="auth-back" onClick={() => go('welcome')}>← Back</button><div className="auth-eyebrow"><Phone size={15}/> SECURE ACCESS</div><h1>Welcome back</h1><p>Sign in with the phone number linked to your approved organisation.</p><form onSubmit={startLogin} className="auth-form"><label className="form-field"><span>Mobile number *</span><input value={phone} onChange={(e) => { setPhone(e.target.value); setError(''); }} inputMode="numeric" maxLength={10} placeholder="10-digit mobile number" required/></label><div className="auth-note"><ShieldIcon size={16}/><span>Only admin-approved organisations can access donor or recipient dashboards.</span></div>{error && <div className="form-error">{error}</div>}<button className="button button-primary button-full" type="submit">Send demo OTP <ArrowRight size={15}/></button></form><p className="auth-switch">New organisation? <button onClick={() => go('register-role')}>Register here</button></p></section>}

        {screen === 'register-role' && <section className="auth-card auth-form-card"><button className="auth-back" onClick={() => go('welcome')}>← Back</button><div className="auth-eyebrow"><Building2 size={15}/> PARTNER REGISTRATION</div><h1>Join SurplusSafe</h1><p>First choose how your organisation will use the platform.</p><div className="auth-role-cards"><button className={role === 'recipient' ? 'auth-role-card selected' : 'auth-role-card'} onClick={() => { setRole('recipient'); setForm((f) => ({...f, orgType: RECIPIENT_TYPES[0]})); }}><HeartHandshake size={22}/><strong>Recipient organisation</strong><span>NGOs, schools, food banks, orphanages</span></button><button className={role === 'donor' ? 'auth-role-card selected' : 'auth-role-card'} onClick={() => { setRole('donor'); setForm((f) => ({...f, orgType: DONOR_TYPES[0]})); }}><CookingPot size={22}/><strong>Food donor</strong><span>Canteens, cloud kitchens, restaurants</span></button></div><button className="button button-primary button-full" onClick={() => go('register-details')}>Continue <ArrowRight size={15}/></button></section>}

        {screen === 'register-details' && <section className="auth-card auth-form-card auth-wide-card"><button className="auth-back" onClick={() => go('register-role')}>← Back</button><div className="auth-eyebrow"><ClipboardCheck size={15}/> VERIFICATION APPLICATION</div><h1>{role === 'recipient' ? 'Recipient registration' : 'Donor registration'}</h1><p>Phone verification is followed by admin review. Account access is enabled only after approval.</p><form onSubmit={startRegistration} className="auth-form"><div className="auth-field-grid"><label className="form-field"><span>Contact person name *</span><input name="fullName" value={form.fullName} onChange={updateForm} required placeholder="Full name"/></label><label className="form-field"><span>Mobile number *</span><input name="phone" value={form.phone} onChange={updateForm} required inputMode="numeric" maxLength={10} placeholder="10-digit mobile number"/></label><label className="form-field"><span>Email (optional)</span><input type="email" name="email" value={form.email} onChange={updateForm} placeholder="name@organisation.org"/></label><label className="form-field"><span>Organisation / business name *</span><input name="orgName" value={form.orgName} onChange={updateForm} required placeholder="Registered organisation name"/></label><label className="form-field"><span>{role === 'recipient' ? 'Recipient type *' : 'Donor type *'}</span><select name="orgType" value={form.orgType} onChange={updateForm}>{(role === 'recipient' ? RECIPIENT_TYPES : DONOR_TYPES).map((item) => <option key={item}>{item}</option>)}</select></label><label className="form-field"><span>Organisation address / city *</span><input name="address" value={form.address} onChange={updateForm} required placeholder="Area, city, state"/></label>{role === 'recipient' ? <label className="form-field form-field-wide"><span>Organisation registration / licence number *</span><input name="registrationNumber" value={form.registrationNumber} onChange={updateForm} required placeholder="Enter valid registration / licence ID"/><small>Admins will review this identifier before account creation.</small></label> : <label className="form-field form-field-wide"><span>FSSAI registration / licence number *</span><input name="fssaiNumber" value={form.fssaiNumber} onChange={updateForm} required placeholder="Enter FSSAI registration / licence ID"/><small>Admins will review this identifier before account creation.</small></label>}</div><div className="auth-note"><ShieldIcon size={16}/><span>This hackathon prototype records a verification application only. It does not validate official licences against government systems.</span></div>{error && <div className="form-error">{error}</div>}<button type="submit" className="button button-primary button-full">Verify phone with OTP <ArrowRight size={15}/></button></form></section>}

        {(screen === 'register-otp' || screen === 'login-otp') && <section className="auth-card auth-form-card"><button className="auth-back" onClick={() => go(screen === 'register-otp' ? 'register-details' : 'login')}>← Back</button><div className="auth-eyebrow"><Phone size={15}/> PHONE VERIFICATION</div><h1>Enter OTP</h1><p>Demo verification code for {screen === 'register-otp' ? form.phone : phone}.</p><form onSubmit={screen === 'register-otp' ? submitRegistrationOtp : finishLogin} className="auth-form"><label className="form-field"><span>One-time password</span><input value={otp} onChange={(e) => { setOtp(e.target.value.replace(/\D/g, '').slice(0,6)); setError(''); }} inputMode="numeric" maxLength={6} placeholder="6-digit OTP" required/></label><div className="demo-otp-box"><strong>Demo OTP: {DEMO_OTP}</strong><span>For prototype demonstration only. No SMS is sent.</span></div>{error && <div className="form-error">{error}</div>}<button className="button button-primary button-full" type="submit">{screen === 'register-otp' ? 'Submit verification application' : 'Verify and login'} <ArrowRight size={15}/></button></form></section>}

        {screen === 'pending' && <section className="auth-card auth-form-card"><div className="pending-illustration"><Clock3 size={28}/></div><div className="auth-eyebrow">APPLICATION SUBMITTED</div><h1>Awaiting admin approval</h1><p>Your phone is demo-verified, but your organisation has not been given an account yet. Admins must review the {role === 'recipient' ? 'registration/licence number' : 'FSSAI number'} first.</p><div className="application-status"><span className="status-dot"/> Pending document verification</div><button className="button button-primary button-full" onClick={() => { setPhone(form.phone); go('login'); }}>Go to login <ArrowRight size={15}/></button><button className="auth-switch-button" onClick={() => go('welcome')}>Back to home</button></section>}

        {screen === 'admin-login' && <section className="auth-card auth-form-card"><button className="auth-back" onClick={() => go('welcome')}>← Back</button><div className="auth-eyebrow"><ShieldIcon size={15}/> ADMIN REVIEW</div><h1>Verification desk</h1><p>Review organisation applications before creating approved accounts.</p><form onSubmit={enterAdmin} className="auth-form"><label className="form-field"><span>Demo admin PIN</span><input value={adminPin} onChange={(e) => { setAdminPin(e.target.value); setError(''); }} inputMode="numeric" maxLength={6} placeholder="6-digit admin PIN" required/></label><div className="demo-otp-box"><strong>Demo admin PIN: {DEMO_ADMIN_PIN}</strong><span>Demo-only gate; production admin access needs server-side authentication.</span></div>{error && <div className="form-error">{error}</div>}<button type="submit" className="button button-primary button-full">Open verification desk <ArrowRight size={15}/></button></form></section>}

        {screen === 'admin' && <section className="auth-card auth-wide-card admin-review-card"><div className="admin-heading"><div><div className="auth-eyebrow"><ShieldIcon size={15}/> ADMIN VERIFICATION DESK</div><h1>Organisation applications</h1><p>Approve only after checking the original documents and licence validity outside this demo.</p></div><button className="button button-secondary" onClick={() => go('welcome')}><LogOut size={15}/> Exit admin</button></div><div className="admin-review-summary"><div><strong>{pendingApps.length}</strong><span>Pending review</span></div><div><strong>{applications.filter((a) => a.status === 'Approved').length}</strong><span>Approved</span></div><div><strong>{applications.filter((a) => a.status === 'Rejected').length}</strong><span>Rejected</span></div></div>{pendingApps.length ? <div className="application-list">{pendingApps.map((app) => <article className="application-card" key={app.id}><div className="application-card-head"><div className="application-avatar">{app.orgName.charAt(0).toUpperCase()}</div><div><strong>{app.orgName}</strong><span>{app.role === 'recipient' ? 'Recipient organisation' : 'Food donor'} · {app.orgType}</span></div><span className="pending-tag">Pending</span></div><div className="application-details"><div><span>Contact</span><strong>{app.fullName}</strong></div><div><span>Phone</span><strong>{app.phone}</strong></div><div><span>Location</span><strong>{app.address}</strong></div><div><span>{app.role === 'recipient' ? 'Registration / licence' : 'FSSAI licence'}</span><strong>{app.role === 'recipient' ? app.registrationNumber : app.fssaiNumber}</strong></div>{app.email && <div><span>Email</span><strong>{app.email}</strong></div>}</div><div className="admin-card-note"><ShieldIcon size={15}/><span>Confirm identity, organisation legitimacy and licence status using official records before approving.</span></div><div className="admin-card-actions"><button className="button button-secondary" onClick={() => reviewApplication(app.id, 'reject')}>Reject</button><button className="button button-primary" onClick={() => reviewApplication(app.id, 'approve')}><BadgeCheck size={16}/> Approve & create account</button></div></article>)}</div> : <div className="auth-empty"><ClipboardCheck size={28}/><strong>No applications pending</strong><p>New recipient and donor registrations will appear here after demo OTP verification.</p></div>}<div className="admin-history"><h3>Recent decisions</h3>{applications.filter((a) => a.status !== 'Pending').slice().reverse().slice(0,5).map((a) => <div className="admin-history-row" key={a.id}><span>{a.orgName}</span><strong className={a.status === 'Approved' ? 'approved-text' : 'rejected-text'}>{a.status}</strong></div>)}</div></section>}
      </div>
      <footer className="auth-footer"><span>SurplusSafe • HackSprint prototype</span><span>Demo-only OTP and local verification workflow</span></footer>
    </div>
  );
}

function App() {
  const [account, setAccount] = useState(() => { try { return JSON.parse(localStorage.getItem(SESSION_KEY) || 'null'); } catch { return null; } });
  function login(nextAccount) { setAccount(nextAccount); try { localStorage.setItem(SESSION_KEY, JSON.stringify(nextAccount)); } catch { /* local demo */ } }
  function logout() { setAccount(null); try { localStorage.removeItem(SESSION_KEY); } catch { /* local demo */ } }
  if (!account) return <AuthPortal onAuthenticated={login} />;
  return <SurplusSafeDashboard account={account} onLogout={logout} />;
}

export default App;
